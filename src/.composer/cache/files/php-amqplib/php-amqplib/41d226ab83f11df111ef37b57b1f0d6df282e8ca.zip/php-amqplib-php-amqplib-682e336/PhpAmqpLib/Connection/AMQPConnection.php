<?php

namespace PhpAmqpLib\Connection;

class AMQPConnection extends AMQPStreamConnection
{
    // just for BC
}