<?php

namespace PhpAmqpLib\Exception;

use PhpAmqpLib\Exception\AMQPException;

/**
 * @deprecated use AMQPProtocolChannelException instead
 */
class AMQPChannelException extends AMQPException
{
}
