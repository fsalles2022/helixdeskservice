<?php

namespace PhpAmqpLib\Exception;

use PhpAmqpLib\Exception\AMQPException;

/**
 * @deprecated use AMQPProtocolConnectionException instead
 */
class AMQPConnectionException extends AMQPException
{
}
